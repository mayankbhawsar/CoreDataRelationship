//
//  CollegeFormViewController.swift
//  CoreDataManagement
//
//  Created by Workstation 158 on 07/11/19.
//  Copyright © 2019 learn. All rights reserved.
//

import UIKit

class CollegeFormViewController: UIViewController {
    
    @IBOutlet weak var txtCollegeName: UITextField!
    @IBOutlet weak var txtCollegeAddress: UITextField!
    @IBOutlet weak var txtCollegeCity: UITextField!
    @IBOutlet weak var txtCollegeUniversity: UITextField!
    @IBOutlet weak var btnSave: UIButton!
    var collegeDetails: College?
    var IsUpdate = false
    var indexRow = Int()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.txtCollegeName.text = collegeDetails?.name?.uppercased()
        self.txtCollegeAddress.text = collegeDetails?.address?.uppercased()
        self.txtCollegeCity.text = collegeDetails?.city?.uppercased()
        self.txtCollegeUniversity.text = collegeDetails?.university?.uppercased()
    }
    override func viewWillAppear(_ animated: Bool) {
        if IsUpdate {
            btnSave.setTitle("Update", for: .normal)
        }else{
            btnSave.setTitle("Save", for: .normal)
        }
    }
}

extension CollegeFormViewController {
    @IBAction func btnCollegeSaveClick(_ sender: UIButton) {
        self.collegeSaveData()
    }
}

extension CollegeFormViewController {
    func collegeSaveData() {
        guard let collegeName = txtCollegeName.text else { return }
        guard let collegeAddress = txtCollegeAddress.text else { return }
        guard let collegeCity = txtCollegeCity.text else { return }
        guard let collegeUniversity = txtCollegeUniversity.text else { return }
        
        let collegeDict = [
            "collegeName":collegeName,
            "collegeAddress":collegeAddress,
            "collegeCity":collegeCity,
            "collegeUniversity":collegeUniversity
        ]
        if IsUpdate {
            DatabaseHelper.sharedInstance.editCollegeData(collegeDict: collegeDict, index: indexRow)
            IsUpdate = false
        }else{
            DatabaseHelper.sharedInstance.saveCollegeData(collegeDict: collegeDict)
        }
    }
}
