//
//  StudentListViewController.swift
//  CoreDataManagement
//
//  Created by Workstation 158 on 21/11/19.
//  Copyright © 2019 learn. All rights reserved.
//

import UIKit

class StudentListViewController: UIViewController {
    
    @IBOutlet weak var studentTblListView: UITableView!
    var arrStudent = [Student]()
    var college: College?
    var deleteStudentRow:NSIndexPath? = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        studentTblListView.register(UITableViewCell.self, forCellReuseIdentifier: "studentCell")
    }
    override func viewWillAppear(_ animated: Bool) {
        if college?.student?.allObjects != nil {
            arrStudent = college?.student?.allObjects as! [Student]
        }
        studentTblListView.reloadData()
    }
    @IBAction func btnAddStudentClick(_ sender: UIBarButtonItem) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let studentFormVC = storyBoard.instantiateViewController(identifier: "StudentFormViewController") as! StudentFormViewController
        studentFormVC.collegeDetails = college
        self.navigationController?.pushViewController(studentFormVC, animated: true)
    }
    func confirmDeleteStudent(planet: String) {
        let alert = UIAlertController(title: "Delete Student Record", message: "Are you sure you want to permanently delete \(planet)?", preferredStyle: .actionSheet)
        let deleteAction = UIAlertAction(title: "Delete", style: .destructive, handler: handleDeleteStdRow(alertAction:))
        let cancelAction = UIAlertAction(title: "Cancle", style: .cancel, handler: cancelDeleteStdRow(alertAction:))
        alert.addAction(deleteAction)
        alert.addAction(cancelAction)
        alert.popoverPresentationController?.sourceView = self.view
        alert.popoverPresentationController?.sourceRect = CGRect(x: self.view.bounds.size.width/2.0,y: self.view.bounds.size.height/2.0,width: 1.0, height: 1.0)
        self.present(alert, animated: true, completion: nil)
    }
    func handleDeleteStdRow(alertAction: UIAlertAction!) -> Void {
        if let indexPath = deleteStudentRow {
            studentTblListView.beginUpdates()
            arrStudent = DatabaseHelper.sharedInstance.deleteStudentData(index: indexPath.row)
            studentTblListView.deleteRows(at: [indexPath as IndexPath], with: .automatic)
            deleteStudentRow = nil
            studentTblListView.endUpdates()
        }
    }
    func cancelDeleteStdRow(alertAction: UIAlertAction!) {
        deleteStudentRow = nil
    }
}

extension StudentListViewController : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrStudent.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "studentCell", for: indexPath)
        if cell != nil {
            cell = UITableViewCell(style: .value2, reuseIdentifier: "studentCell")
        }
        cell.textLabel?.text = arrStudent[indexPath.row].name?.uppercased()
        cell.detailTextLabel?.text = arrStudent[indexPath.row].phone?.uppercased()
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let studentDetailVC = storyBoard.instantiateViewController(identifier: "StudentDetailViewController") as! StudentDetailViewController
        studentDetailVC.studentDetail = arrStudent[indexPath.row]
        studentDetailVC.collegeDetails = college
//        studentDetailVC.stdRowIndex = indexPath.row
        self.navigationController?.pushViewController(studentDetailVC, animated: true)
    }
  /*  func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            deleteStudentRow = indexPath as NSIndexPath
            confirmDeleteStudent(planet: "Delete Student Row Data")
        }
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return false
    }*/
}
