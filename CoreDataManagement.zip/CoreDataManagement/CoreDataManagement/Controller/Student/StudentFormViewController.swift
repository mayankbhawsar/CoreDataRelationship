//
//  StudentFormViewController.swift
//  CoreDataManagement
//
//  Created by Workstation 158 on 21/11/19.
//  Copyright © 2019 learn. All rights reserved.
//

import UIKit

class StudentFormViewController: UIViewController {
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var btnSaveClick: UIButton!
    
    @IBOutlet weak var imgView: UIImageView!
    var collegeDetails: College?
    var studentDetails: Student?
    var IsUpdate = false
//    var indexRow = Int()
    override func viewDidLoad() {
        super.viewDidLoad()
     
        self.txtName.text = studentDetails?.name?.uppercased()
        self.txtEmail.text = studentDetails?.email?.uppercased()
        self.txtPhone.text = studentDetails?.phone?.uppercased()
       
        if IsUpdate {
            btnSaveClick.setTitle("Update", for: .normal)
        }else{
            btnSaveClick.setTitle("Save", for: .normal)
        }
    }
    
    @IBAction func btnSaveStudentClick(_ sender: UIButton) {
        guard let name = txtName.text else { return }
        guard let email = txtEmail.text else { return }
        guard let phone = txtPhone.text else { return }
        let studentDict = [
            "studentName":name,
            "studentEmail":email,
            "studentPhone":phone
        ]
        if IsUpdate {
            DatabaseHelper.sharedInstance.editStudentData(studentDetail:studentDetails!, studentDict: studentDict,college: collegeDetails!)
            IsUpdate = false
        }else{
             DatabaseHelper.sharedInstance.saveStudentData(studentDict: studentDict,college: collegeDetails!)
        }
       
    }
    
}
