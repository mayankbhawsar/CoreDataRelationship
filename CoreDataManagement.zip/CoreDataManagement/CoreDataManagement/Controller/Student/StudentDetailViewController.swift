//
//  StudentDetailViewController.swift
//  CoreDataManagement
//
//  Created by Workstation 158 on 25/11/19.
//  Copyright © 2019 learn. All rights reserved.
//

import UIKit

class StudentDetailViewController: UITableViewController {
    
    @IBOutlet weak var lblStdName: UILabel!
    @IBOutlet weak var lblStdEmail: UILabel!
    @IBOutlet weak var lblStdPhone: UILabel!
    
    var studentDetail: Student?
    var collegeDetails: College?
//    var stdRowIndex = Int()
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        lblStdName.text = studentDetail?.name?.uppercased() ?? ""
        lblStdEmail.text = studentDetail?.email?.uppercased() ?? ""
        lblStdPhone.text = studentDetail?.phone?.uppercased() ?? ""
    }
    @IBAction func btnEditStudentClick(_ sender: UIBarButtonItem) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let formVC = storyBoard.instantiateViewController(identifier: "StudentFormViewController") as! StudentFormViewController
        formVC.IsUpdate = true
        formVC.studentDetails = studentDetail
        formVC.collegeDetails = collegeDetails
//        formVC.indexRow = stdRowIndex
        self.navigationController?.pushViewController(formVC, animated: false)
    }
}
