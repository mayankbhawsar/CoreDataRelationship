//
//  DatabaseHelper.swift
//  CoreDataManagement
//
//  Created by Workstation 158 on 07/11/19.
//  Copyright © 2019 learn. All rights reserved.
//

import UIKit
import CoreData

class DatabaseHelper: NSObject {
    
    static let sharedInstance = DatabaseHelper()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    func saveCollegeData(collegeDict:[String:String]) {
        let college = NSEntityDescription.insertNewObject(forEntityName: "College", into: context) as! College
        college.name = collegeDict["collegeName"]
        college.address = collegeDict["collegeAddress"]
        college.city = collegeDict["collegeCity"]
        college.university = collegeDict["collegeUniversity"]
        do {
            try context.save()
        } catch  let err{
            print("College Save Error :- \(err.localizedDescription)")
        }
    }
    func getAllCollegeData() -> [College] {
        var arrCollege = [College]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "College")
        do {
            arrCollege = try context.fetch(fetchRequest) as! [College]
        } catch let err {
            print("Error in College fetch :-\(err.localizedDescription)")
        }
        return arrCollege
    }
    func deleteCollegeData(index: Int) -> [College] {
        var deleteData = self.getAllCollegeData()
        context.delete(deleteData[index])
        deleteData.remove(at: index)
        do {
            try context.save()
        } catch let err {
            print("error :- \(err.localizedDescription)")
        }
        return deleteData
    }
    func editCollegeData(collegeDict:[String:String],index:Int) {
        let college = self.getAllCollegeData()
        college[index].name = collegeDict["collegeName"]
        college[index].address = collegeDict["collegeAddress"]
        college[index].city = collegeDict["collegeCity"]
        college[index].university = collegeDict["collegeUniversity"]
        do {
            try context.save()
        } catch let err {
            print("Error :\(err.localizedDescription)")
        }
    }
    func saveStudentData(studentDict:[String:String], college:College) {
        let student = NSEntityDescription.insertNewObject(forEntityName: "Student", into: context) as! Student
        student.name = studentDict["studentName"]
        student.email = studentDict["studentEmail"]
        student.phone = studentDict["studentPhone"]
        student.university = college
        do {
            try context.save()
        } catch  let err{
            print("College Save Error :- \(err.localizedDescription)")
        }
    }
    func getAllStudentData() -> [Student] {
        var arrStudent = [Student]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Student")
        do {
            arrStudent = try context.fetch(fetchRequest) as! [Student]
        } catch let err {
            print("Error in Student fetch :-\(err.localizedDescription)")
        }
        return arrStudent
    }
    func deleteStudentData(index: Int) -> [Student] {
        var deleteData = self.getAllStudentData()
        context.delete(deleteData[index])
        deleteData.remove(at: index)
        do {
            try context.save()
        } catch let err {
            print("error :- \(err.localizedDescription)")
        }
        return deleteData
    }
    func editStudentData(studentDetail:Student,studentDict:[String:String],college:College) {
        let arrStudent = [studentDetail]
        if (arrStudent.count) > 0 {
            arrStudent[0].name = studentDict["studentName"]
            arrStudent[0].email = studentDict["studentEmail"]
            arrStudent[0].phone = studentDict["studentPhone"]
            arrStudent[0].university = college
        }
        do {
            try context.save()
        } catch let err {
            print("Error :\(err.localizedDescription)")
        }
    }
}
