//
//  CollegeListViewCell.swift
//  CoreDataManagement
//
//  Created by Workstation 158 on 07/11/19.
//  Copyright © 2019 learn. All rights reserved.
//

import UIKit

class CollegeListViewCell: UITableViewCell {
    
    @IBOutlet weak var lblCollegeName: UILabel!
    @IBOutlet weak var lblCollegeCity: UILabel!
    @IBOutlet weak var lblCollegeUniversity: UILabel!
    
    var college:College?{
        didSet{
            lblCollegeName.text = "College Name: \(college?.name ?? "")"
            lblCollegeCity.text = "City: \(college?.city ?? "")"
            lblCollegeUniversity.text = "University: \(college?.university ?? "")"
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}   
