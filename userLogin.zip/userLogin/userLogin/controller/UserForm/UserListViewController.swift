//
//  UserListViewController.swift
//  userLogin
//
//  Created by Workstation 158 on 27/12/19.
//  Copyright © 2019 userSignInUp. All rights reserved.
//

import UIKit

class UserListViewController: UIViewController {
    
    @IBOutlet weak var tblUserList: UITableView!
    var arrUser : [NSDictionary]? = nil
    var userRole : String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        if  userRole == "Admin" {
            arrUser?.removeAll()
            arrUser = DataBaseHelper.sharedInstance.getAllUserDetails()
            tblUserList.reloadData()
        }
        else {
            tblUserList.reloadData()
        }
    }
}
extension UserListViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrUser!.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserDetails", for: indexPath) as! UserDetails
        cell.imgViewer.image = UIImage(data:(arrUser![indexPath.row].value(forKey: "img") as! Data) )
        cell.lblRole?.text = (arrUser![indexPath.row].value(forKey: "name") as! String)
        cell.lblName?.text = (arrUser![indexPath.row].value(forKey: "roleName") as! String)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let userDetailsVC = self.storyboard?.instantiateViewController(identifier: "DetailViewController") as! DetailViewController
        userDetailsVC.arrUser = [arrUser![indexPath.row]]
        self.navigationController?.pushViewController(userDetailsVC, animated: true)
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
}
