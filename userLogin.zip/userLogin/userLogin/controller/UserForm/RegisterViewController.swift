//
//  RegisterViewController.swift
//  userLogin
//
//  Created by Workstation 158 on 24/12/19.
//  Copyright © 2019 userSignInUp. All rights reserved.
//

import UIKit
import CoreData

class RegisterViewController: UIViewController {
    
    @IBOutlet weak var imgPicker: UIImageView!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtEmailID: UITextField!
    @IBOutlet weak var txtDOB: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtCPassword: UITextField!
    @IBOutlet weak var btnCheckAdmin: UIButton!
    @IBOutlet weak var btnSave: UIButton!
    @IBOutlet weak var backView: UIView!
    
    var checkValue: Int = 1
    let imagePicker = UIImagePickerController()
    let datePicker = UIDatePicker()
    var formatter = DateFormatter()
  
    override func viewDidLoad() {
        super.viewDidLoad()
        backView.layer.shadowOffset = CGSize(width: 8, height: 8)
        backView.layer.shadowRadius = 5
        backView.layer.shadowOpacity = 0.6
        backView.layer.shadowColor = UIColor.systemBlue.cgColor
        backView.layer.shouldRasterize = true
        backView.layer.rasterizationScale = UIScreen.main.scale
       
        txtPassword.autocorrectionType = .no
        txtPassword.isSecureTextEntry = true
        txtPassword.textContentType = .newPassword
        formatter.dateFormat = "dd/MM/yyyy"
        setDatePicker()
    }
    @IBAction func clickCheckBox(_ sender: UIButton) {
        if checkValue == 0 {
            btnCheckAdmin.setImage(UIImage(systemName: "none"), for: .normal)
            checkValue += 1
        }
        else {
            btnCheckAdmin.setImage(UIImage(systemName: "checkmark"), for: .normal)
            checkValue -= 1
        }
    }
    @objc func selectImage(gesture : UITapGestureRecognizer) {
        self.openImagePicker()
    }
    @IBAction func btnClickRegister(_ sender: UIButton) {
        let result = validation()
        if result.0 {
            let usno = DataBaseHelper.sharedInstance.test(email: txtEmailID.text!)
            if usno.count < 1 {
                userSaveData()
                let alert = ViewController().alertMessage(alertmsg: "Thank You for Join Us")
                self.present(alert, animated: true, completion: nil)
                txtName.text = "";txtEmailID.text = "";txtDOB.text = "";txtPassword.text = "";txtCPassword.text = ""; txtAddress.text = ""; imgPicker.image = UIImage(named: ""); btnCheckAdmin.setImage(UIImage(systemName: "none"), for: .normal)
            }
            else {
                let alert = ViewController().alertMessage(alertmsg: "Email-ID Already Register With Us..!")
                self.present(alert, animated: true, completion: nil)
                txtEmailID.text = ""
            }
        }
        else {
            let alert = ViewController().alertMessage(alertmsg: "Please \(validation().1)")
            self.present(alert, animated: true, completion: nil)
        }
    }
}
extension RegisterViewController: UINavigationControllerDelegate,UIImagePickerControllerDelegate  {
    func userSaveData() {
        let jpg = self.imgPicker.image?.jpegData(compressionQuality: 0.65)
        let dob = formatter.date(from: txtDOB.text!)
        if dob == nil {
            let alert = ViewController().alertMessage(alertmsg: "Please Enter Valid DOB")
            self.present(alert, animated: true, completion: nil)
        }
        var userRole: String
        if checkValue == 0 {
            userRole = "Admin"
        }
        else {
            userRole = "User"
        }
        let userDict = [
            "userName": txtName!.text as AnyObject,
            "userAddress": txtAddress!.text as AnyObject,
            "userEmail": txtEmailID!.text as AnyObject,
            "userDOB": dob as Any,
            "userPass": txtPassword!.text as AnyObject,
            "userConPass": txtCPassword!.text as AnyObject,
            "userPhoto": jpg as AnyObject,
            "userRole" : userRole as AnyObject
        ]
        DataBaseHelper.sharedInstance.saveUserDetails(userDetails: userDict as [String : AnyObject])
    }
    override func viewDidLayoutSubviews() {
        imgPicker.layer.borderColor = UIColor.darkGray.cgColor
        imgPicker.layer.cornerRadius = 50.0
        imgPicker.clipsToBounds = true
        imgPicker.layer.borderWidth = 3.0
        btnCheckAdmin.layer.borderColor = UIColor.black.cgColor
        btnCheckAdmin.layer.cornerRadius = 2.0
        btnCheckAdmin.layer.borderWidth = 2.0
        btnCheckAdmin.clipsToBounds = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(selectImage(gesture:)))
        tapGesture.numberOfTapsRequired = 1
        self.imgPicker.isUserInteractionEnabled = true
        self.imgPicker.addGestureRecognizer(tapGesture)
    }
    func openImagePicker ()
    {
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum) {
            imagePicker.delegate = self
            imagePicker.sourceType = .savedPhotosAlbum
            imagePicker.allowsEditing = false
            present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        dismiss(animated: true, completion: nil)
        if let img = info[.originalImage] as? UIImage {
            self.imgPicker.image = img
        }
    }
    func validation() -> (Bool,String) {
        if (self.imgPicker.image?.jpegData(compressionQuality: 0.65)) == nil {
            return (false, "Upload Photo")
        }
        else if txtName?.text == "" {
            return (false,"Enter Username")
        }
        else if !isValidEmail(emailStr: txtEmailID.text!) {
            return (false,"Enter Valid EmailID")
        }
        else if txtDOB?.text == "" {
            return (false,"Enter DOB")
        }
        else if txtAddress?.text == "" {
            return (false,"Enter Address")
        }
        else if txtPassword?.text == "" {
            return (false,"Enter Password")
        }
        else if txtCPassword?.text == "" {
            return (false,"Enter Confirm Password")
        }
        else if txtPassword.text != txtCPassword.text {
            return (false,"Check Confirm Password")
        }
            
        else {
            return (true,"true")
        }
    }
    func isValidEmail(emailStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: emailStr)
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if (txtDOB != nil) {
            textField.resignFirstResponder()
            return false
        }
        return true
    }
    func setDatePicker() {
        datePicker.datePickerMode = .date
        let calendar = Calendar.current
        var maxDateComponent = calendar.dateComponents([.day,.month,.year], from: Date())
        maxDateComponent.day = 01
        maxDateComponent.month = 01
        maxDateComponent.year = 2020
        
        let maxDate = calendar.date(from: maxDateComponent)

        self.datePicker.maximumDate =  maxDate! as Date
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneDatePicker));
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker));
        toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)
        txtDOB.inputAccessoryView = toolbar
        txtDOB.inputView = datePicker
    }
    @objc func doneDatePicker() {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        txtDOB.text = formatter.string(from: datePicker.date as Date)
        self.view.endEditing(true)
    }
    
    @objc func cancelDatePicker() {
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //        textField.resignFirstResponder()
        switch textField {
        case txtDOB:
            txtDOB.resignFirstResponder()
            txtDOB.inputView = datePicker
        default:
            break
        }
        return true
    }
}
/*
 /23 Dec
 1.Add Functionality of Add Department Details.
 2.Add Functionality of Show Department Details.
 RECRUITMENT FOR OFFICE ASSISTANT CUM DATA ENTRY OPERATOR,NIWARI-2019
 1.Test Application Form in local development environment and rectify bugs.
 2.Tested Application Form according to testing team criteria(Also checkout the previous application bug in new application).
 3.Test Application Form according rule book rules.
 
 //24 Dec
 1.Add Database in spot Billing Mobile App.
 2.Make Connectivity With Database (Department Details).
 3.Add Update Information Functionality.
 4.Check Validation In Add Department Details.
 5.Check Validation in Bill Payment(MPWZ).
 

 
 //26 Dec
 1.Make Function For Check Printer connectivity with device.
 2.Make Function For Search Printer device to pair with device.
 3.Make Function For Print Receipt form printer Consumer get receipt on spot.
 4.Make function for bill payment password based and pin base.
 5.Review Payment System before pay Bill.
 
 //27 Dec 1 bje tk
 1.Check Data Against IVRS ID Using (MPWZ) Web Service (PostMPWZData Method).
 2.Insert Data (Amount,Email ID,Mobile No) Using (MPWZ) Webservice (RAPDRPinsert Method).
 
 //28 Dec
 1.configure printer with Mobile App.
 2.Set Values For print from printer.
 3.Check Printer connectivity with device
 4.Search Printer device and pair with device via bluetooth.
 5.check bluetooth visiability.
 6.Print Receipt on spot after bill payment Done.
 
 
 
 */
