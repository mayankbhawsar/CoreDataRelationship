//
//  DetailViewController.swift
//  userLogin
//
//  Created by Workstation 158 on 27/12/19.
//  Copyright © 2019 userSignInUp. All rights reserved.
//

import UIKit


class DetailViewController: UIViewController {
    
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblDOB: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    
    var arrUser:[NSDictionary]? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if arrUser!.isEmpty == false {
            imgView.image = UIImage(data: arrUser![0].value(forKey: "img") as! Data)
            lblUsername.text = "Name: \(arrUser![0].value(forKey: "name") as! String)"
            lblEmail.text = "Email ID: \(arrUser![0].value(forKey: "emailID") as! String)"
            lblDOB.text = "DOB: \(arrUser![0].value(forKey: "dob") as! Date)"
            lblAddress.text = "Address: \(arrUser![0].value(forKey: "address") as! String)"
        }
    }
    @IBAction func btnLogOut(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
}
extension DetailViewController {
    override func viewDidLayoutSubviews() {
        imgView.layer.borderColor = UIColor.darkGray.cgColor
        imgView.layer.cornerRadius = 50.0
        imgView.clipsToBounds = true
        imgView.layer.borderWidth = 3.0
    }
}
