//
//  ViewController.swift
//  userLogin
//
//  Created by Workstation 158 on 24/12/19.
//  Copyright © 2019 userSignInUp. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var backView: UIView!
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    override func viewDidLoad() {
        super.viewDidLoad()
        backView.layer.shadowOffset = CGSize(width: 10, height: 10)
        backView.layer.shadowRadius = 10
        backView.layer.shadowOpacity = 0.7
        backView.layer.shadowColor = UIColor.blue.cgColor
        backView.layer.shouldRasterize = true
        backView.layer.rasterizationScale = UIScreen.main.scale
    }
    @IBAction func clickLogin(_ sender: UIButton) {
        if validation().0 {
            let fetchRequest = NSFetchRequest<NSDictionary>(entityName: "UserMaster")
            fetchRequest.resultType = .dictionaryResultType
            fetchRequest.predicate = NSPredicate(format: "emailID == %@ ",txtName.text!)
            fetchRequest.propertiesToFetch = ["password"]
            do {
                let result = try context.fetch(fetchRequest)
                if result.count > 0 {
                    if (result[0].value(forKey: "password") as! String) == txtPassword.text {
                        UserLogin()
                    }
                    else {
                        let alert = ViewController().alertMessage(alertmsg: "Incorrect Password")
                        self.present(alert, animated: true, completion: nil)
                    }
                }
                else {
                    let alert = ViewController().alertMessage(alertmsg: "Incorrect Password")
                    self.present(alert, animated: true, completion: nil)
                }
            } catch let error as NSError {
                print(error)
            }
        }
        else {
            let alert = ViewController().alertMessage(alertmsg: "Please Enter \(validation().1)")
            self.present(alert, animated: true, completion: nil)
        }
    }
}
extension ViewController {
    
    func UserLogin()  {
        let result = DataBaseHelper.sharedInstance.test(email: txtName.text!)
        if result.count == 0 {
            let alert = ViewController().alertMessage(alertmsg: "Please Register Your Self")
            self.present(alert, animated: true, completion: nil)
        }
        else if result.count > 0 {
            txtName.text = ""
            txtPassword.text = ""
            let userDetailsVC = self.storyboard?.instantiateViewController(identifier: "UserListViewController") as! UserListViewController
            userDetailsVC.arrUser = result
            userDetailsVC.userRole = result[0].value(forKey: "roleName") as! String
            self.navigationController?.pushViewController(userDetailsVC, animated: true)
        }
    }
    func validation() -> (Bool,String) {
        if !isValidEmail(emailStr: txtName.text!) {
            return (false," Valid EmailID")
        }
        else if txtPassword?.text == "" {
            return (false," Password")
        }
        else {
            return (true,"true")
        }// hr@agnitotechnologies.com
    }
    func isValidEmail(emailStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: emailStr)
    }
    func alertMessage(alertmsg: String) -> UIAlertController {
        let alert = UIAlertController(title: "Alert", message: alertmsg, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        return alert
    }
    
}
