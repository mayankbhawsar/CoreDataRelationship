//
//  DataBaseHelper.swift
//  userLogin
//
//  Created by Workstation 158 on 26/12/19.
//  Copyright © 2019 userSignInUp. All rights reserved.
//

import UIKit
import CoreData
class DataBaseHelper: NSObject {
    
    static let sharedInstance = DataBaseHelper()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func saveUserDetails(userDetails:[String:AnyObject]) {
        let userData = NSEntityDescription.insertNewObject(forEntityName: "UserMaster", into: context) as! UserMaster
        userData.name = (userDetails["userName"] as! String)
        userData.address = (userDetails["userAddress"] as! String)
        userData.emailID = (userDetails["userEmail"] as! String)
        userData.dob = (userDetails["userDOB"] as! String)
        userData.password = (userDetails["userPass"] as! String)
        userData.cpassword = (userDetails["userConPass"] as! String)
        userData.img = (userDetails["userPhoto"] as! Data)
        userData.roleName = (userDetails["userRole"] as! String)
        do {
            try context.save()
        } catch let err {
            print("Error: \(err.localizedDescription)")
        }
    }
    func getAllUserDetails() -> [UserMaster] {
        var arrUserData = [UserMaster]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "UserMaster")
        do {
            arrUserData = try context.fetch(fetchRequest) as! [UserMaster]
        } catch let err {
            print("\(err.localizedDescription)")
        }
        return arrUserData
    }
    func checkDuplidate(email : String) -> Int {
        var allUsers = [UserMaster]()
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "UserMaster")
        fetchRequest.predicate = NSPredicate(format: "emailID == %@", email)
        do {
            allUsers = try context.fetch(fetchRequest) as! [UserMaster]
//            assert(allUsers.count < 2)
        } catch {
            // handle error
        }
        return allUsers.count
    }
}
