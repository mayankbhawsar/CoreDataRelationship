//
//  UserDetails.swift
//  userLogin
//
//  Created by Workstation 158 on 27/12/19.
//  Copyright © 2019 userSignInUp. All rights reserved.
//

import UIKit

class UserDetails: UITableViewCell {
    @IBOutlet weak var imgViewer: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblRole: UILabel!
  
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
