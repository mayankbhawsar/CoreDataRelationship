//
//  DataBaseHelper.swift
//  userLogin
//
//  Created by Workstation 158 on 26/12/19.
//  Copyright © 2019 userSignInUp. All rights reserved.
//

import UIKit
import CoreData
class DataBaseHelper: NSObject {
    
    static let sharedInstance = DataBaseHelper()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func saveUserDetails(userDetails:[String:AnyObject]) {

        let userData = NSEntityDescription.insertNewObject(forEntityName: "UserMaster", into: context) as! UserMaster
        userData.name = (userDetails["userName"] as! String)
        userData.address = (userDetails["userAddress"] as! String)
        userData.emailID = (userDetails["userEmail"] as! String)
        userData.dob = (userDetails["userDOB"] as! Date)
        userData.password = (userDetails["userPass"] as! String)
        userData.cpassword = (userDetails["userConPass"] as! String)
        userData.img = (userDetails["userPhoto"] as! Data)
        userData.roleName = (userDetails["userRole"] as! String)
        do {
            try context.save()
        } catch let err {
            print("Error: \(err.localizedDescription)")
        }
    }
    func getAllUserDetails() -> [NSDictionary] {
        var arrUserData: [NSDictionary]? = nil
        let fetchRequest = NSFetchRequest<NSDictionary>(entityName: "UserMaster")
        fetchRequest.resultType = .dictionaryResultType
        do {
            arrUserData = try context.fetch(fetchRequest) 
        } catch let err {
            print("\(err.localizedDescription)")
        }
        return arrUserData!
    }
    func test(email : String) -> [NSDictionary]  {
        var result : [NSDictionary]? = nil
        let fetchRequest = NSFetchRequest<NSDictionary>(entityName: "UserMaster")
        fetchRequest.resultType = .dictionaryResultType
        fetchRequest.predicate = NSPredicate(format: "emailID == %@ ",email)
        //         fetchRequest.propertiesToFetch = ["roleName"]
        do {
            result = try context.fetch(fetchRequest)
        } catch let error as NSError {
            print(error)
        }
        return result!
    }
}
