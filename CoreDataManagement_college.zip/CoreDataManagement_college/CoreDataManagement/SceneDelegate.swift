//
//  SceneDelegate.swift
//  CoreDataManagement
//
//  Created by Workstation 158 on 07/11/19.
//  Copyright © 2019 learn. All rights reserved.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?


    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        // Use this method to optionally configure and attach the UIWindow `window` to the provided UIWindowScene `scene`.
        // If using a storyboard, the `window` property will automatically be initialized and attached to the scene.
        // This delegate does not imply the connecting scene or session are new (see `application:configurationForConnectingSceneSession` instead).
        guard let _ = (scene as? UIWindowScene) else { return }
    }

    func sceneDidDisconnect(_ scene: UIScene) {
        // Called as the scene is being released by the system.
        // This occurs shortly after the scene enters the background, or when its session is discarded.
        // Release any resources associated with this scene that can be re-created the next time the scene connects.
        // The scene may re-connect later, as its session was not neccessarily discarded (see `application:didDiscardSceneSessions` instead).
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        // Called when the scene has moved from an inactive state to an active state.
        // Use this method to restart any tasks that were paused (or not yet started) when the scene was inactive.
    }

    func sceneWillResignActive(_ scene: UIScene) {
        // Called when the scene will move from an active state to an inactive state.
        // This may occur due to temporary interruptions (ex. an incoming phone call).
    }

    func sceneWillEnterForeground(_ scene: UIScene) {
        // Called as the scene transitions from the background to the foreground.
        // Use this method to undo the changes made on entering the background.
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        // Called as the scene transitions from the foreground to the background.
        // Use this method to save data, release shared resources, and store enough scene-specific state information
        // to restore the scene back to its current state.

        // Save changes in the application's managed object context when the application transitions to the background.
        (UIApplication.shared.delegate as? AppDelegate)?.saveContext()
    }
    /*
     func fibonaci(n: Int) {
     var fiboNumberOne = 1
     var fiboNumberTwo = 0
     for _ in 0..<n
     {
     let temp = fiboNumberOne + fiboNumberTwo
     fiboNumberOne = fiboNumberTwo
     fiboNumberTwo = temp
     print("Fibonaci \(fiboNumberTwo)")
     }
     }
     // Factorial
     func factorial(of num: Int) -> Int {
     if num == 1 {
     return 1
     } else {
     return num * factorial(of:num - 1)
     }
     
     }
     // function for compare Two Array Element
     func array() {
     /*   var a = [4,3,2,1,5,4]
     a = a.sorted { $0 > $1 }
     print(a)
     print(a.sorted(by: >))*/
     
     let array1 = ["a","b","c","d"]
     let array2 = ["a","c","c","d"]
     let result = zip(array1, array2).enumerated().filter() {
     $1.0 == $1.1
     }.map{$0.0}
     print(result)
     }
     
     // Check the prime number  //single line code
     func prime(_ number: Int) -> Bool {
     return (1...number).filter({number % $0 == 0}).count <= 2
     }
     // print * pyramid in swift 4
     func printStar() {
     let treeHeight = 5
     let treeWidth = treeHeight * 2 - 1
     for lineNumber in 1...treeHeight {
     // How many asterisks to print
     let stars = 2 * lineNumber - 1
     var line = ""
     // Half the non-star space
     let spaces = (treeWidth - stars) / 2
     if spaces > 0 {
     line = String(repeating: " ", count: spaces)
     }
     line += String(repeating: "*", count: stars)
     print (line)
     }
     }
     */

}

