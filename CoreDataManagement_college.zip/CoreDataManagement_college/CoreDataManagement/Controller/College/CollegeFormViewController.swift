//
//  CollegeFormViewController.swift
//  CoreDataManagement
//
//  Created by Workstation 158 on 07/11/19.
//  Copyright © 2019 learn. All rights reserved.
//

import UIKit

class CollegeFormViewController: UIViewController {
    
    @IBOutlet weak var txtCollegeName: UITextField!
    @IBOutlet weak var txtCollegeAddress: UITextField!
    @IBOutlet weak var txtCollegeCity: UITextField!
    @IBOutlet weak var txtCollegeUniversity: UITextField!
    @IBOutlet weak var btnSave: UIButton!
    @IBOutlet weak var imgViewPicker: UIImageView!
    var collegeDetails: College?
    var IsUpdate = false
    var indexRow = Int()
    let imagePicker = UIImagePickerController()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.txtCollegeName.text = collegeDetails?.name?.uppercased()
        self.txtCollegeAddress.text = collegeDetails?.address?.uppercased()
        self.txtCollegeCity.text = collegeDetails?.city?.uppercased()
        self.txtCollegeUniversity.text = collegeDetails?.university?.uppercased()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(selectImage(gesture:)))
        tapGesture.numberOfTapsRequired = 1
        self.imgViewPicker.isUserInteractionEnabled = true
        self.imgViewPicker.addGestureRecognizer(tapGesture)
    }
    override func viewWillAppear(_ animated: Bool) {
        if IsUpdate {
            imgViewPicker.isHidden = true
            imgViewPicker.backgroundColor = UIColor.clear
            btnSave.setTitle("Update", for: .normal)
        }else{
            btnSave.setTitle("Save", for: .normal)
        }
    }
    @objc func selectImage(gesture : UITapGestureRecognizer){
        self.openImagePicker()
    }
}

extension CollegeFormViewController {
    @IBAction func btnCollegeSaveClick(_ sender: UIButton) {
        self.collegeSaveData()
    }
}

extension CollegeFormViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    func openImagePicker ()
    {
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            imagePicker.delegate = self
            imagePicker.sourceType = .savedPhotosAlbum
            imagePicker.allowsEditing = false
            present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        dismiss(animated: true, completion: nil)
        if let img = info[.originalImage] as? UIImage {
            self.imgViewPicker.image = img
        }
    }
    
    func collegeSaveData() {
      
        guard let collegeName = txtCollegeName.text else { return }
        guard let collegeAddress = txtCollegeAddress.text else { return }
        guard let collegeCity = txtCollegeCity.text else { return }
        guard let collegeUniversity = txtCollegeUniversity.text else { return }
       
        let collegeDict = [
            "collegeName":collegeName ,
            "collegeAddress":collegeAddress ,
            "collegeCity":collegeCity,
            "collegeUniversity":collegeUniversity,
            ]
        if IsUpdate {
            DatabaseHelper.sharedInstance.editCollegeData(collegeDict: collegeDict, index: indexRow)
            IsUpdate = false
        }else{
            guard let jpg = self.imgViewPicker.image?.jpegData(compressionQuality: 0.65) else {return}
            DatabaseHelper.sharedInstance.saveCollegeData(collegeDict: collegeDict, at : jpg)
        }
    }
}
