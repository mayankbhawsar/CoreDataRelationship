//
//  CollegeDetailViewController.swift
//  CoreDataManagement
//
//  Created by Workstation 158 on 14/11/19.
//  Copyright © 2019 learn. All rights reserved.
//

import UIKit

class CollegeDetailViewController: UITableViewController {
    
    @IBOutlet weak var lblCollegeName: UILabel!
    @IBOutlet weak var lblCollegeAddress: UILabel!
    @IBOutlet weak var lblCollegeCity: UILabel!
    @IBOutlet weak var lblCollegeUniversity: UILabel!
    
    var collegeDetail: College?
    var indexRow = Int()
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        lblCollegeName.text = collegeDetail?.name?.uppercased() ?? ""
        lblCollegeCity.text = collegeDetail?.city?.uppercased() ?? ""
        lblCollegeAddress.text = collegeDetail?.address?.uppercased() ?? ""
        lblCollegeUniversity.text = collegeDetail?.university?.uppercased() ?? ""
    }
    @IBAction func btnEditClick(_ sender: UIBarButtonItem) {
        let formVC = self.storyboard?.instantiateViewController(identifier: "CollegeFormViewController") as! CollegeFormViewController
        formVC.IsUpdate = true
        formVC.collegeDetails = collegeDetail
        formVC.indexRow = indexRow
        self.navigationController?.pushViewController(formVC, animated: false)
    }
}
