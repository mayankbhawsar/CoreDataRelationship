//
//  ViewController.swift
//  CoreDataManagement
//
//  Created by Workstation 158 on 07/11/19.
//  Copyright © 2019 learn. All rights reserved.
//

import UIKit

class CollegeListViewController: UIViewController {
    
    @IBOutlet weak var tblCollegeListView: UITableView!
    var arrCollege = [College]()
    var deleteRowIndex:NSIndexPath? = nil
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.arrCollege = DatabaseHelper.sharedInstance.getAllCollegeData()
        self.tblCollegeListView.reloadData()
    }
    @IBAction func btnCollegeAddClick(_ sender: UIBarButtonItem) {
        let collegeForm = self.storyboard?.instantiateViewController(identifier: "CollegeFormViewController") as! CollegeFormViewController
        self.navigationController?.pushViewController(collegeForm, animated: true)
    }
    func confirmDelete(planet: String) {
        let alert = UIAlertController(title: "Delete Row Data", message: "Are you sure you want to permanently delete \(planet)?", preferredStyle: .actionSheet)
        let deleteAction = UIAlertAction(title: "Delete", style: .destructive, handler: handleDeleteRow(alertAction:))
        let cancelAction = UIAlertAction(title: "Cancle", style: .cancel, handler: cancelDeleteRow(alertAction:))
        alert.addAction(deleteAction)
        alert.addAction(cancelAction)
        alert.popoverPresentationController?.sourceView = self.view
        alert.popoverPresentationController?.sourceRect = CGRect(x: self.view.bounds.size.width/2.0,y: self.view.bounds.size.height/2.0,width: 1.0, height: 1.0)
        self.present(alert, animated: true, completion: nil)
    }
    func handleDeleteRow(alertAction: UIAlertAction!) -> Void {
        if let indexPath = deleteRowIndex {
            tblCollegeListView.beginUpdates()
            arrCollege = DatabaseHelper.sharedInstance.deleteCollegeData(index: indexPath.row)
            tblCollegeListView.deleteRows(at: [indexPath as IndexPath], with: .automatic)
            deleteRowIndex = nil
            tblCollegeListView.endUpdates()
        }
    }
    func cancelDeleteRow(alertAction: UIAlertAction!) {
        deleteRowIndex = nil
    }
}

extension CollegeListViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrCollege.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CollegeListViewCell", for: indexPath) as! CollegeListViewCell
        cell.college = arrCollege[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            //            arrCollege = DatabaseHelper.sharedInstance.deleteCollegeData(index: indexPath.row)
            //            self.arrCollege = DatabaseHelper.sharedInstance.getAllCollegeData()
            deleteRowIndex = indexPath as NSIndexPath
            //            let planetToDelete = arrCollege[indexPath.row]
            //            print(planetToDelete)
            confirmDelete(planet: "Row Data")
        }
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let collegeDetailsVC = self.storyboard?.instantiateViewController(identifier: "CollegeDetailViewController") as! CollegeDetailViewController
        collegeDetailsVC.collegeDetail = arrCollege[indexPath.row]
        collegeDetailsVC.indexRow = indexPath.row
        self.navigationController?.pushViewController(collegeDetailsVC, animated: true)
    }
}
