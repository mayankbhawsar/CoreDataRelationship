//
//  DatabaseHelper.swift
//  CoreDataManagement
//
//  Created by Workstation 158 on 07/11/19.
//  Copyright © 2019 learn. All rights reserved.
//

import UIKit
import CoreData

class DatabaseHelper: NSObject {
    
    static let sharedInstance = DatabaseHelper()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func saveCollegeData(collegeDict:[String:String], at ImageData : Data)
    {
        let college = NSEntityDescription.insertNewObject(forEntityName: "College", into: context) as! College
        college.name = collegeDict["collegeName"]
        college.address = collegeDict["collegeAddress"]
        college.city = collegeDict["collegeCity"]
        college.university = collegeDict["collegeUniversity"]
        college.img = ImageData
        do {
            try context.save()
        } catch  let err {
            print("College Save Error :- \(err.localizedDescription)")
        }
    }
    func getAllCollegeData() -> [College] {
        var arrCollege = [College]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "College")
        do {
            arrCollege = try context.fetch(fetchRequest) as! [College]
        } catch let err {
            print("Error in College fetch :-\(err.localizedDescription)")
        }
        return arrCollege
    }
    func deleteCollegeData(index: Int) -> [College] {
        var deleteData = self.getAllCollegeData()
        context.delete(deleteData[index])
        deleteData.remove(at: index)
        do {
            try context.save()
        } catch let err {
            print("error :- \(err.localizedDescription)")
        }
        return deleteData
    }
    func editCollegeData(collegeDict:[String:String],index:Int) {
        let college = self.getAllCollegeData()
        college[index].name = collegeDict["collegeName"]
        college[index].address = collegeDict["collegeAddress"]
        college[index].city = collegeDict["collegeCity"]
        college[index].university = collegeDict["collegeUniversity"]
//        college[index].img = (collegeDict["img"] as AnyObject as! Data)
        do {
            try context.save()
        } catch let err {
            print("Error :\(err.localizedDescription)")
        }
    }
}

